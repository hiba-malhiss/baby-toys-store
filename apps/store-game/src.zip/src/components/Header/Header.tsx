import { useNavigate, useLocation } from 'react-router-dom';
import { Button, Flex } from '@baby-toys/ui-kit';
import { useAdminAuth } from '../../context/AuthContext';
import { useLoginDialogStore } from '../../store/useLoginDialogStore';
import LoginDialog from '../LoginDialog/LoginDialog';
import { useAdminLogout } from '../../api/authApi';
import s from './Header.module.css';

const Header = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, user, hasPermission } = useAdminAuth();
  const { isOpen, open, close } = useLoginDialogStore();
  const { mutateAsync: logoutApi } = useAdminLogout();

  const logout = async () => {
    try {
      await logoutApi();
      navigate('/');
    } catch (error) {
      console.error('Logout failed:', error);
      navigate('/');
    }
  };

  // Determine current mode based on location
  const isAdminMode = location.pathname.startsWith('/admin');
  const isPlayerMode = location.pathname.startsWith('/play');

  return (
    <header className={s.header}>
      <Flex justify="between" align="center" fullWidth>
        <Flex align="center" spacing="m">
          <div
            className={s.logo}
            onClick={() => navigate('/play')}
          >
            🎮 Games
          </div>
        </Flex>

        <Flex align="center" spacing="m">
          {isAuthenticated ? (
            <>
              <span className={s.userInfo}>
                👋 {user?.firstName || user?.email}
              </span>
              
              {/* Mode Toggle Switch */}
              {<div className={s.modeToggle} style={{
                display: 'flex',
                backgroundColor: '#f1f5f9',
                borderRadius: '20px',
                padding: '4px',
                position: 'relative'
              }}>
                <button
                  onClick={() => navigate('/admin')}
                  style={{
                    padding: '8px 16px',
                    border: 'none',
                    borderRadius: '16px 0 0 16px',
                    backgroundColor: isPlayerMode ? '#10b981' : 'transparent',
                    color: isPlayerMode ? 'white' : '#6b7280',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '500',
                    transition: 'all 0.2s'
                  }}
                >
                  🎮 Player
                </button>
                <button
                  onClick={() => navigate('/admin')}
                  style={{
                    padding: '8px 16px',
                    border: 'none',
                    borderRadius: '0 16px 16px 0',
                    backgroundColor: isPlayerMode ? '#10b981' : 'transparent',
                    color: isPlayerMode ? 'white' : '#6b7280',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '500',
                    transition: 'all 0.2s'
                  }}
                >
                  🛠️ Admin
                </button>
              </div>

              <Button appearance="link" color="primary" onClick={logout}>
                Logout
              </Button>
            </>
          ) : (
            <>
              <Button appearance="outline" color="primary" onClick={open}>
                Admin Login
              </Button>
            </>
          )}
        </Flex>
      </Flex>

      <LoginDialog open={isOpen} onClose={close} />
    </header>
  );
};

export default Header;
