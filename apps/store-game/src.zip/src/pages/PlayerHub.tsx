import { useNavigate } from 'react-router-dom';
import { useBoardsQuery } from '@/api/boardApi';
import { useMemoryDecksQuery } from '@/api/memoryApi';
import { Play } from 'lucide-react';
import s from './PlayerHub.module.css';

export default function PlayerHub() {
  const nav = useNavigate();
  const { data: boardsPage, isLoading: boardsLoading } = useBoardsQuery({ page: 0, size: 50 });
  const { data: memoryPage, isLoading: memoryLoading } = useMemoryDecksQuery({ page: 0, size: 50 });

  const memoryDecks = memoryPage?.content ?? [];

  return (
    <div className={s.page}>
      <div className={s.inner}>
        <div className={s.header}>
          <h1 className={s.title}>🎮 Choose a Game</h1>
        </div>

        {/* Memory decks */}
        <section className={s.section}>
          <h2 className={s.sectionTitle}>🃏 Memory Match</h2>
          <div className={s.grid}>
            {memoryLoading && [1, 2, 3].map((i) => <div key={i} className={s.skeleton} />)}
            {!memoryLoading && (
              <>
                {/* Always show the built-in default deck */}
                <div className={s.gameCard}>
                  <div className={s.cardImage}>
                    <span className={s.cardEmoji}>🃏</span>
                    <span className={s.cardBadge}>Memory</span>
                  </div>
                  <div className={s.cardBody}>
                    <h3 className={s.cardTitle}>Default Deck</h3>
                    <p className={s.cardMeta}>12 equation pairs · built-in</p>
                  </div>
                  <button className={s.cardPlay} onClick={() => nav('/play/memory/default')}>
                    <Play size={13} /> Play
                  </button>
                </div>

                {/* API decks */}
                {memoryDecks.map((deck) => (
                  <div key={deck.id} className={s.gameCard}>
                    <div className={s.cardImage}>
                      <span className={s.cardEmoji}>🃏</span>
                      <span className={s.cardBadge}>Memory</span>
                    </div>
                    <div className={s.cardBody}>
                      <h3 className={s.cardTitle}>{deck.name}</h3>
                      <p className={s.cardMeta}>{deck.pairCount} pairs</p>
                    </div>
                    <button className={s.cardPlay} onClick={() => nav(`/play/memory/${deck.id}`)}>
                      <Play size={13} /> Play
                    </button>
                  </div>
                ))}
              </>
            )}
          </div>
        </section>

        {/* Board games */}
        <section className={s.section}>
          <h2 className={s.sectionTitle}>🎨 Paint by Equation</h2>
          {boardsLoading && (
            <div className={s.grid}>
              {[1, 2, 3].map((i) => (
                <div key={i} className={s.skeleton} />
              ))}
            </div>
          )}
          {!boardsLoading && (boardsPage?.content ?? []).length === 0 && (
            <p className="empty-text">No boards available yet. Ask an admin to create one.</p>
          )}
          {!boardsLoading && (boardsPage?.content ?? []).length > 0 && (
            <div className={s.grid}>
              {boardsPage!.content.map((b) => (
                <div key={b.id} className={s.gameCard}>
                  <div className={s.cardImage}>
                    {b.imageUrl ? (
                      <img
                        src={b.imageUrl}
                        alt={b.name}
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      />
                    ) : (
                      <span className={s.cardEmoji}>🎨</span>
                    )}
                    <span className={s.cardBadge}>Board</span>
                  </div>
                  <div className={s.cardBody}>
                    <h3 className={s.cardTitle}>{b.name}</h3>
                    <p className={s.cardMeta}>
                      {b.width}×{b.height} grid
                    </p>
                  </div>
                  <button className={s.cardPlay} onClick={() => nav(`/play/board/${b.id}`)}>
                    <Play size={13} /> Play
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
